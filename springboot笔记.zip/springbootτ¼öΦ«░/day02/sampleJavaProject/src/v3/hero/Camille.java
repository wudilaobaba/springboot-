package v3.hero;

import v3.ISkill;

public class Camille implements ISkill {
    public void q(){
        System.out.println("Camille q");
    }
    public void w(){
        System.out.println("Camille w");
    }
    public void e(){
        System.out.println("Camille e");
    }
    public void r(){
        System.out.println("Camille r");
    }
}
