package v2;

public interface ISkill {
    void q();
    void w();
    void e();
    void r();
}
