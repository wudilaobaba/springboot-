package v2.hero;

import v2.ISkill;

public class Irelia implements ISkill {
    public void q(){
        System.out.println("Irelia q");
    }
    public void w(){
        System.out.println("Irelia w");
    }
    public void e(){
        System.out.println("Irelia e");
    }
    public void r(){
        System.out.println("Irelia r");
    }
}
