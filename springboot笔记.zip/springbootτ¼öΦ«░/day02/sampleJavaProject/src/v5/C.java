package v5;

public class C implements Letter{
    @Override
    public void saySelf() {
        System.out.println("I'm C");
    }
}
