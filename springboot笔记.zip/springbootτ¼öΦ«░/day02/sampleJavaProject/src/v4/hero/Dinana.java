package v4.hero;

import v4.ISkill;

public class Dinana implements ISkill {
    public void q(){
        System.out.println("Diana q");
    }
    public void w(){
        System.out.println("Diana w");
    }
    public void e(){
        System.out.println("Diana e");
    }
    public void r(){
        System.out.println("Diana r");
    }
}
