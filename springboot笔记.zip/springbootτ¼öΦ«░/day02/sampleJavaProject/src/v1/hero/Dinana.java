package v1.hero;

public class Dinana {
    public void q(){
        System.out.println("Diana q");
    }
    public void w(){
        System.out.println("Diana w");
    }
    public void e(){
        System.out.println("Diana e");
    }
    public void r(){
        System.out.println("Diana r");
    }
}
