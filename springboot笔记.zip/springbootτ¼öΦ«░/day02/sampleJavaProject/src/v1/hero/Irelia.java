package v1.hero;

public class Irelia {
    public void q(){
        System.out.println("Irelia q");
    }
    public void w(){
        System.out.println("Irelia w");
    }
    public void e(){
        System.out.println("Irelia e");
    }
    public void r(){
        System.out.println("Irelia r");
    }
}
