package com.whj.springbootcode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootcodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootcodeApplication.class, args);
	}

}
