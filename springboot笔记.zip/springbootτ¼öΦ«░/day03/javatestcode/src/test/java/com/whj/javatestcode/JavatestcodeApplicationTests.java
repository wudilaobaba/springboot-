package com.whj.javatestcode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavatestcodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
