import React,{
  Fragment
} from 'react';
import Index from "./page/Index"
function App() {
  return (
    <Fragment>
      <Index/>
    </Fragment>
  );
}

export default App;
