import React,{
  Component,
  Fragment
} from "react"
import {BASEURL,GETHEADERS,POSTHEADERS} from '../../api'
import {getReq,postReq} from 'network-request-bywhj'
import {transferDatas} from 'js-fun-bywhj'
class Index extends Component{
  constructor(props,context){
    super(props,context)
  }
  render(){
    return(
      <Fragment>
        <h1 onClick={this.get.bind(this,'name01')}>11111111111111111111....</h1>
      </Fragment>
    )
  }
  get(themeName) {
    getReq(transferDatas(`${BASEURL}/v1/banner/name/${themeName}`, {}, 'get'), GETHEADERS, (responseData) => {
      console.log(responseData);
    })
  }
  post(themeName) {
    postReq(`${BASEURL}/v1/theme/name/${themeName}/with_spu?start=1&count=2`, POSTHEADERS, transferDatas('', {}, 'post'), (responseData) => {
      console.log(responseData);
    })
  }
}
export default Index;
