自定义注解：用来进行自定义参数校验

PassWordEqual 判断两次代码是否一致