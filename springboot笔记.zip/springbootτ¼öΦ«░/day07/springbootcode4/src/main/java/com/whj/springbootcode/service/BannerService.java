package com.whj.springbootcode.service;

import com.whj.springbootcode.model.Banner;

public interface BannerService {
    Banner getByName(String name);
}
