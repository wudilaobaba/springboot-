package com.whj.springbootcode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootcodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
