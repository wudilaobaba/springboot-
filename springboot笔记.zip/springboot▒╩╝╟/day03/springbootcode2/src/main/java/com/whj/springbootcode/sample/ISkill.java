package com.whj.springbootcode.sample;

public interface ISkill {
    void q();
    void w();
    void e();
    void r();
}
