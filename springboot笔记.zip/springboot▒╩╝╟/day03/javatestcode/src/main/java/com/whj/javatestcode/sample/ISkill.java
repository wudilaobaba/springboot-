package com.whj.javatestcode.sample;

public interface ISkill {
    void q();
    void w();
    void e();
    void r();
}
