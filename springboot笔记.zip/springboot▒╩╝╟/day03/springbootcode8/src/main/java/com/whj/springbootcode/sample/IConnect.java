package com.whj.springbootcode.sample;

public interface IConnect {
    void connect();
}
