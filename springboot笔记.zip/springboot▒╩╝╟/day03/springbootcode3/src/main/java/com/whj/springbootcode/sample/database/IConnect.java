package com.whj.springbootcode.sample.database;

public interface IConnect {
    void connect();
}
