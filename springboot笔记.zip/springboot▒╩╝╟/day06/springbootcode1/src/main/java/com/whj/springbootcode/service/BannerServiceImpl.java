package com.whj.springbootcode.service;

import org.springframework.stereotype.Service;

@Service
public class BannerServiceImpl implements BannerService{
    public void getByName(String name){
        //根据name进行查询数据库
        System.out.println("123456789987654321");
    }
}
