package com.whj.springbootcode.service;

public interface BannerService {
    void getByName(String name);
}
