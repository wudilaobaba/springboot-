package com.whj.springbootcode.dto;

import lombok.*;

@Builder
public class PeosonDTO {
    private String name;
    private Integer age;
}
