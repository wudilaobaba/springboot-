package v3;

public interface ISkill {
    void q();
    void w();
    void e();
    void r();
}
