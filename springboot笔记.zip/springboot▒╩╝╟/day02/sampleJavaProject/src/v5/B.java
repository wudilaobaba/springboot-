package v5;

public class B implements Letter{
    @Override
    public void saySelf() {
        System.out.println("I'm B");
    }
}
