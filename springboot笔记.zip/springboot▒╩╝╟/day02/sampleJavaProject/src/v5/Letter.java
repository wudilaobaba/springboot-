package v5;

public interface Letter {
    void saySelf();
}
